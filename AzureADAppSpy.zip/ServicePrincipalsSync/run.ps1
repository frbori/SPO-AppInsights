# Input bindings are passed in via param block.
param($Timer)

# Gets the access token for connecting to Graph
$accessTokenGraph = Get-AccessTokenForGraph
# Connects to Graph
ConnectTo-MSGraph -AccessToken $accessTokenGraph

try {
    $servicePrincipals = Get-MgServicePrincipal -All -ExpandProperty Owners
    $servicePrincipals = $servicePrincipals | Select-Object AppId, Id, DisplayName, ServicePrincipalType, SignInAudience, AccountEnabled, AppRoleAssignmentRequired, AppOwnerOrganizationId, Homepage,
        @{Name="CreatedDateTime";Expression={Get-Date $_.AdditionalProperties.createdDateTime -Format "yyyy-MM-dd HH:mm:ss"}}, 
        @{Name="SecretsNumber";Expression={$_.passwordCredentials.Count}}, 
        @{Name="CertificatesNumber";Expression={$_.keyCredentials.Count}},
        @{Name="SecretsLastExpire";Expression={($_.PasswordCredentials.EndDateTime | Sort-Object -Descending | Select-Object -First 1).ToString("yyyy-MM-dd")}},
        @{Name="CertificatesLastExpire";Expression={($_.KeyCredentials.EndDateTime | Sort-Object -Descending | Select-Object -First 1).ToString("yyyy-MM-dd")}},
        @{Name="Owners";Expression={
            $users = $_.Owners | Where-Object {$_.AdditionalProperties.'@odata.type' -eq "#microsoft.graph.user"}
            $serviceP = $_.Owners | Where-Object {$_.AdditionalProperties.'@odata.type' -eq "#microsoft.graph.servicePrincipal"}
            $users = $users.AdditionalProperties.displayName -join ","
            $serviceP = ($serviceP.AdditionalProperties.appDisplayName + "(" + $serviceP.Id + ")") -join ","
            ($users + "," + $serviceP).Replace("()","").Trim(',')
        }},
        @{Name="OwnersEmail";Expression={
            $users = $_.Owners | Where-Object {$_.AdditionalProperties.'@odata.type' -eq "#microsoft.graph.user"}
            $users = $users.AdditionalProperties.mail -join ","
            $users
        }},
        @{Name="ReplyUrls";Expression={$_.ReplyUrls -join ","}},
        @{Name="TenantId";Expression={$env:TENANT_ID}}
}
catch {
    throw "Couldn't retrieve or parse Service Principals. $($_.Exception.Message)"
}

# Gets the access token for connecting to SQL
$accessTokenSQL = Get-AccessTokenForSQL
# Opens the connection
$SqlConnection = Open-SQLConnection -AccessToken $accessTokenSQL
# Invokes the stored procedure
Invoke-SQLStoredProcedure -SqlConnection $SqlConnection -StoredProcedure "MergeServicePrincipals"  -Param $servicePrincipals