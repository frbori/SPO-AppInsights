# Input bindings are passed in via param block.
param($Timer)

# Gets the access token for connecting to Graph
$accessTokenGraph = Get-AccessTokenForGraph
# Connects to Graph
ConnectTo-MSGraph -AccessToken $accessTokenGraph

try {
    # Defining arrays
    $jsonObj = @()  # array of PSCustomObject, will be converted in json
    $spOauth2PermissionGrantAlreadyRetrieved = @()
    $spAppRoleAssignmentAlreadyRetrieved = @()
    
    # Retrieves all Application Registrations
    $appRegs = Get-MgApplication -All -Property AppId, RequiredResourceAccess
    # Retrieves all Enterprise Applications
    $servicePrincipals = Get-MgServicePrincipal -All -Property Id, AppId, AppOwnerOrganizationId, Oauth2PermissionScopes, AppRoles, DisplayName

    #region Getting permissions assigned to Service Principals whose app registration has been defined in this tenant
    foreach ($appReg in $appRegs) {
        $requiredResourceAccess = $appReg.RequiredResourceAccess  # gets the resources tha app reg needs to have access to
        foreach ($requiredResource in $requiredResourceAccess) {  # for each resource (e.g. Graph, SharePoint, Power Automate, etc.) the app reg needs permission on
            # Retrieving the Service Principal that represents the resource the app reg needs permissions on
            $spRequiredResource = $servicePrincipals | Where-Object { $_.AppId -eq $requiredResource.ResourceAppId }  # a permission is relative to a specific Service Principal. First we check in the tmp array to save Graph API calls
            # Retrieving the Service Principal associated to the current app reg
            $servicePrincipal = $servicePrincipals | Where-Object { $_.AppId -eq $appReg.AppId }
            foreach ($resourceAccess in $requiredResource.ResourceAccess) {  # for each permission from the current resource
                if ($resourceAccess.Type -eq "Scope" -and $null -ne $servicePrincipal) {  # delegated perm and existing service principal
                    $permType = "Delegated"
                    $servicePrincipalId = $servicePrincipal.Id
                    $role = $spRequiredResource.Oauth2PermissionScopes | Where-Object { $_.Id -eq $resourceAccess.Id }
                    $oauth2PermissionGrant = $spOauth2PermissionGrantAlreadyRetrieved | Where-Object { $_.ClientId -eq $servicePrincipal.Id }
                    if ($null -eq $oauth2PermissionGrant) {
                        $oauth2PermissionGrant = Get-MgServicePrincipalOauth2PermissionGrant -ServicePrincipalId $servicePrincipal.Id
                        $spOauth2PermissionGrantAlreadyRetrieved += $oauth2PermissionGrant
                    }
                    $granted = $null -ne ($oauth2PermissionGrant | Where-Object { $_.ResourceId -eq $spRequiredResource.Id -and $_.Scope -like "*$($role.Value)*" })
                    if ($true -eq $granted) {
                        $consentType = (($oauth2PermissionGrant | Where-Object { $_.ResourceId -eq $spRequiredResource.Id -and $_.Scope -like "*$($role.Value)*" }).ConsentType | Select-Object -Unique) -join ","
                    }
                    else {
                        $consentType = $null
                    }
                }
                elseif ($resourceAccess.Type -eq "Scope") {  # delegated perm and no service principal
                    $role = $spRequiredResource.Oauth2PermissionScopes | Where-Object { $_.Id -eq $resourceAccess.Id }
                    $consentType = $null
                    $permType = "Delegated"
                    $servicePrincipalId = $null
                    $granted = $false
                }
                elseif ($resourceAccess.Type -ne "Scope" -and $null -ne $servicePrincipal) {  # application perm and existing service principal
                    $permType = "Application"
                    $servicePrincipalId = $servicePrincipal.Id
                    $role = $spRequiredResource.AppRoles | Where-Object { $_.Id -eq $resourceAccess.Id }
                    $appRoleAssignment = $spAppRoleAssignmentAlreadyRetrieved | Where-Object { $_.PrincipalId -eq $servicePrincipal.Id }
                    if ($null -eq $appRoleAssignment) {
                        $appRoleAssignment = Get-MgServicePrincipalAppRoleAssignment -ServicePrincipalId $servicePrincipal.Id
                        $spAppRoleAssignmentAlreadyRetrieved += $appRoleAssignment
                    }
                    $granted = $null -ne ($appRoleAssignment | Where-Object { $_.ResourceId -eq $spRequiredResource.Id -and $_.AppRoleId -eq $resourceAccess.Id })
                    $consentType = $null
                }
                elseif ($resourceAccess.Type -ne "Scope") {  # application perm and no service principal
                    $role = $spRequiredResource.AppRoles | Where-Object { $_.Id -eq $resourceAccess.Id }
                    $consentType = $null
                    $permType = "Application"
                    $servicePrincipalId = $null
                    $granted = $false
                }
                $jsonObj += [PSCustomObject]@{
                    appId               = $appReg.AppId
                    Id                  = $servicePrincipalId
                    resourceDisplayName = $spRequiredResource.DisplayName
                    permission          = $role.Value
                    permissionType      = $permType
                    granted             = $granted
                    consentType         = $consentType
                }
            }
        }
    }
    #endregion
    
    #region Getting permissions assigned to Service Principals whose app registration has been defined in another tenant
    $servicePrincipalsExternal = $servicePrincipals | Where-Object { $_.AppOwnerOrganizationId -ne $env:TENANT_ID }
    foreach ($servicePrincipal in $servicePrincipalsExternal) {  # for each service principal that whose app registration has been defined in another tenant
        #region Check for Delegated permissions
        $oauth2PermissionGrant = $spOauth2PermissionGrantAlreadyRetrieved | Where-Object { $_.ClientId -eq $servicePrincipal.Id }
        if ($null -eq $oauth2PermissionGrant) {
            $oauth2PermissionGrant = Get-MgServicePrincipalOauth2PermissionGrant -ServicePrincipalId $servicePrincipal.Id
            $spOauth2PermissionGrantAlreadyRetrieved += $oauth2PermissionGrant
        }
        $uniqueResourceIds = $oauth2PermissionGrant | Select-Object ResourceId -Unique
        foreach ($uniqueResourceId in $uniqueResourceIds) {
            # Retrieving the Service Principal that represents the resource the app reg needs permissions on
            $spRequiredResource = $servicePrincipals | Where-Object { $_.Id -eq $uniqueResourceId.ResourceId }  # a permission is relative to a specific Service Principal. First we check in the tmp array to save Graph API calls
            $uniqueScopes = ($oauth2PermissionGrant | Where-Object { $_.ResourceId -eq $uniqueResourceId.ResourceId }).Scope.Trim() -split " " | Select-Object -Unique
            foreach ($sc in $uniqueScopes) {
                $consentType = (($oauth2PermissionGrant | Where-Object { $_.ResourceId -eq $uniqueResourceId.ResourceId -and $_.Scope.Contains($sc) }).ConsentType | Select-Object -Unique) -join ","
                $jsonObj += [PSCustomObject]@{
                    appId               = $servicePrincipal.AppId
                    Id                  = $servicePrincipal.Id
                    resourceDisplayName = $spRequiredResource.DisplayName
                    permission          = $sc
                    permissionType      = "Delegated"
                    granted             = $true
                    consentType         = $consentType
                }
            }
        }
        #endregion

        #region Check for Application permissions
        $appRoleAssignment = $spAppRoleAssignmentAlreadyRetrieved | Where-Object { $_.PrincipalId -eq $servicePrincipal.Id }
        if ($null -eq $appRoleAssignment) {
            $appRoleAssignment = Get-MgServicePrincipalAppRoleAssignment -ServicePrincipalId $servicePrincipal.Id
            $spAppRoleAssignmentAlreadyRetrieved += $appRoleAssignment
        }
        foreach ($appRole in $appRoleAssignment) {
            # Retrieving the Service Principal that represents the resource the app reg needs permissions on
            $spRequiredResource = $servicePrincipals | Where-Object { $_.Id -eq $appRole.ResourceId }  # a permission is relative to a specific Service Principal. First we check in the tmp array to save Graph API calls
            $role = $spRequiredResource.AppRoles | Where-Object { $_.Id -eq $appRole.AppRoleId }
            $jsonObj += [PSCustomObject]@{
                appId               = $servicePrincipal.AppId
                Id                  = $servicePrincipal.Id
                resourceDisplayName = $spRequiredResource.DisplayName
                permission          = $role.Value
                permissionType      = "Application"
                granted             = $true
                consentType         = $null
            }
        }
        #endregion
        #endregion
    }
}
catch {
    throw "An error occurred. $($_.Exception.Message)"
}

# Gets the access token for connecting to SQL
$accessTokenSQL = Get-AccessTokenForSQL
# Opens the connection
$SqlConnection = Open-SQLConnection -AccessToken $accessTokenSQL
# Invokes the stored procedure
Invoke-SQLStoredProcedure -SqlConnection $SqlConnection -StoredProcedure "MergeAppRegPermissions"  -Param $jsonObj